#ifndef __GSS_FRAMEWORK_H
#define __GSS_FRAMEWORK_H 1

#include <GSS/gssapi.h>
#include <GSS/gssapi_krb5.h>
#include <GSS/gssapi_spnego.h>
#include <GSS/gssapi_apple.h>

#endif /* __GSS_FRAMEWORK_H */
